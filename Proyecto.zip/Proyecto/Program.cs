﻿// See https://aka.ms/new-console-template for more information
using System.ComponentModel.DataAnnotations;
using static System.Runtime.InteropServices.JavaScript.JSType;

Console.WriteLine("Hello, World!");
Console.WriteLine("Proyecto");
Console.WriteLine("Car Wash");

Random random = new Random();

string operador;
string placa = "";
string cliente = "";
int vehiculo = 0;

double tarifaBase = 0;
double tarifaRines = 0;
double total = 0;

bool ticketActivo = false;
bool servicioRines = false;

int carrosAtendidos = 0;
int carrosConRines = 0;
double totalGanancias = 0;

Console.Write("Ingrese el nombre del operador: ");
operador = Console.ReadLine();

int opcion;

do
{
    Console.WriteLine("MENU");
    Console.WriteLine("1. Crear Ticket");
    Console.WriteLine("2. Lavado de Rines");
    Console.WriteLine("3. Consultar Cobro");
    Console.WriteLine("4. Registrar Salida");
    Console.WriteLine("5. Salir");

    opcion = Convert.ToInt32(Console.ReadLine());

    switch (opcion)
    {
        case 1:
            if (ticketActivo)
            {
                Console.WriteLine("Ya existe un ticket activo");
                break;
            }

            int ticket = random.Next(1000, 9999);
            Console.WriteLine("Ticket: " + ticket);

            Console.Write("Placa (6 caracteres): ");
            placa = Console.ReadLine().Trim();

            if (placa.Length != 6 || placa.Contains(" "))
            {
                Console.WriteLine("Placa inválida");
                break;
            }

            Console.Write("Nombre del cliente: ");
            cliente = Console.ReadLine();

            Console.Write("Tipo (1 = Sedan, 2 = Pickup / SUV): ");
            vehiculo = Convert.ToInt32(Console.ReadLine());

            if (vehiculo == 1)
                tarifaBase = 50;
            else if (vehiculo == 2)
                tarifaBase = 75;
            else
            {
                Console.WriteLine("Tipo inválido");
                break;
            }

            ticketActivo = true;
            Console.WriteLine("Ticket creado correctamente");
            break;

        case 2:
            if (!ticketActivo)
            {
                Console.WriteLine("No hay ticket activo");
                break;
            }

            if (!servicioRines)
            {
                Console.Write("Tamaño de rines (12 al 22): ");
                int size = Convert.ToInt32(Console.ReadLine());

                if (size >= 12 && size <= 16)
                    tarifaRines = 30;
                else if (size >= 17 && size <= 19)
                    tarifaRines = 40;
                else if (size >= 20 && size <= 22)
                    tarifaRines = 60;
                else
                {
                    Console.WriteLine("Tamaño inválido");
                    break;
                }

                servicioRines = true;
                Console.WriteLine("Servicio agregado");
            }
            else
            {
                Console.WriteLine("1. Cancelar servicio");
                Console.WriteLine("2. Mantener servicio");
                int op = Convert.ToInt32(Console.ReadLine());

                if (op == 1)
                {
                    tarifaRines = 0;
                    servicioRines = false;
                    Console.WriteLine("Servicio eliminado");
                }
            }
            break;

        case 3:
            if (!ticketActivo)
            {
                Console.WriteLine("No hay ticket activo");
                break;
            }

            total = tarifaBase + tarifaRines;

            Console.WriteLine("DETALLE");
            Console.WriteLine("Base: Q" + tarifaBase);
            Console.WriteLine("Rines: Q" + tarifaRines);
            Console.WriteLine("TOTAL: Q" + total);
            break;

        case 4:
            if (!ticketActivo)
            {
                Console.WriteLine("No hay ticket activo");
                break;
            }

            total = tarifaBase + tarifaRines;

            Console.WriteLine("Total a pagar: Q" + total);

            // dinámica premio
            Console.Write("Elige un número (1-3): ");
            int userNum = Convert.ToInt32(Console.ReadLine());
            int randomNum = random.Next(1, 4);

            Console.WriteLine("Número generado: " + randomNum);

            if (userNum == randomNum)
                Console.WriteLine("Premio: Lavado gratis la próxima vez");
            else
                Console.WriteLine("Suerte para la próxima");

            // acumuladores
            carrosAtendidos++;
            totalGanancias += total;

            if (servicioRines)
                carrosConRines++;

            // resetear el ticket
            ticketActivo = false;
            servicioRines = false;
            tarifaBase = 0;
            tarifaRines = 0;
            total = 0;

            Console.WriteLine("Salida registrada.");
            break;

        case 5:
            Console.WriteLine("REPORTE FINAL");
            Console.WriteLine("Carros atendidos: " + carrosAtendidos);
            Console.WriteLine("Con servicio extra: " + carrosConRines);
            Console.WriteLine("Ganancias totales: Q" + totalGanancias);
            break;

        default:
            Console.WriteLine("Opción inválida");
            break;
    }

} while (opcion != 5);
    